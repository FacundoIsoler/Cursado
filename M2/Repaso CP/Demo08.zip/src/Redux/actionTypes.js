export const ADD_PRODUCT = "ADD_PRODUCT"
export const GET_PRODUCTS = "GET_PRODUCTS"