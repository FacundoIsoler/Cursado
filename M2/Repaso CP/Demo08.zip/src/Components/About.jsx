import React from 'react'

function About() {
  return (
    <div>Cosas hermosas sobre nosotrxs y link a Linkedin y GitHub que queda muy PRO</div>
  )
}

export default About